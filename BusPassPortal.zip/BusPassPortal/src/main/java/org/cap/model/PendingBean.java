package org.cap.model;

import java.time.LocalDate;

public class PendingBean {
	
	private int transactionId;
	private String employeeId;
	private LocalDate transactionDate;
	private double monthlyFare;
	private int totalkilometer;
	private LocalDate startDate;
	
	public PendingBean() {
		
	}

	
	public PendingBean(int transactionId, String employeeId, LocalDate transactionDate, double monthlyFare,
			int totalkilometer, LocalDate startDate) {
		super();
		this.transactionId = transactionId;
		this.employeeId = employeeId;
		this.transactionDate = transactionDate;
		this.monthlyFare = monthlyFare;
		this.totalkilometer = totalkilometer;
		this.startDate = startDate;
	}


	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public LocalDate getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}

	public double getMonthlyFare() {
		return monthlyFare;
	}

	public void setMonthlyFare(double monthlyFare) {
		this.monthlyFare = monthlyFare;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	
	

	public int getTotalkilometer() {
		return totalkilometer;
	}


	public void setTotalkilometer(int totalkilometer) {
		this.totalkilometer = totalkilometer;
	}


	@Override
	public String toString() {
		return "PendingBean [transactionId=" + transactionId + ", employeeId=" + employeeId + ", transactionDate="
				+ transactionDate + ", monthlyFare=" + monthlyFare + ", totalkilometer=" + totalkilometer
				+ ", startDate=" + startDate + "]";
	}



	
	

}
