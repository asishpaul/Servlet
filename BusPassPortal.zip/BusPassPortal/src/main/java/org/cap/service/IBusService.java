package org.cap.service;

import java.util.List;

import org.cap.model.PassRequestBean;
import org.cap.model.PendingBean;
import org.cap.model.RouteBean;

public interface IBusService {
	public List<RouteBean> getAllRoutes();
	
	public RouteBean addRoute(RouteBean routeBean);
	
	public PendingBean createPending(PendingBean pendingBean);

	public List<PassRequestBean> getPendingRequest();

}
