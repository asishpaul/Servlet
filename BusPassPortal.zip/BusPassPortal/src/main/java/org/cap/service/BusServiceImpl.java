package org.cap.service;

import java.util.List;

import org.cap.dao.BusServiceDaoImpl;
import org.cap.dao.IBusServiceDao;
import org.cap.model.PassRequestBean;
import org.cap.model.PendingBean;
import org.cap.model.RouteBean;

public class BusServiceImpl implements IBusService{
	
	private IBusServiceDao busServiceDao;
	
	public BusServiceImpl() {
		this.busServiceDao=new BusServiceDaoImpl();
	}

	@Override
	public List<RouteBean> getAllRoutes() {
		
		return busServiceDao.getAllRoutes();
	}

	@Override
	public RouteBean addRoute(RouteBean routeBean) {
		
		return busServiceDao.addRoute(routeBean);
	}

	@Override
	public PendingBean createPending(PendingBean pendingBean) {
		
		return busServiceDao.createRequest(pendingBean);
	}

	@Override
	public List<PassRequestBean> getPendingRequest() {

		return busServiceDao.getPendingRequest();
	}

}
