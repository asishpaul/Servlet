package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.PassRequestBean;
import org.cap.model.PendingBean;
import org.cap.service.BusServiceImpl;
import org.cap.service.IBusService;

/**
 * Servlet implementation class PendingRequestServlet
 */
@WebServlet("/PendingRequestServlet")
public class PendingRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IBusService busService;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		busService=new BusServiceImpl();
		PrintWriter out=response.getWriter();
		List<PassRequestBean> request1=busService.getPendingRequest();
		out.println("<html>"
				+ "<body>");
		out.println("<h3>All Route Details</h3>"
				+ "<table>"
				+ "<tr>"
				+"<th>Request Id</th>"
				+ "<th>EmployeeId</th>"
				+ "<th>Email</th>"
				+ "<th>Pick Up Location</th>"
				+"<th>Status</th>"
				+ "</tr>");
		
		for(PassRequestBean requestBean:request1) {
			out.println("<tr>"
					+ "<td>"+requestBean.getRequestId()+"</td>"
					+ "<td>"+requestBean.getEmployeeId()+"<br>"
					+requestBean.getFirstName() + "</td>"
					+"<td>"+requestBean.getEmail()+"</td>"
					//+ "<td>"+requestBean.getDateOfJoining()+"</td>"
							+ "<td>"+requestBean.getPickuploc()+"</td>"
									//+ "<td>"+requestBean.getPickuptime()+"</td>"
											+ "<td>"+requestBean.getStatus()+"</td>"
					+ "</tr>");
		}
		
	out.println("</table>");
		
		
		out.println("</body>"
				+ "</html>");
		
	}

	
	
}
