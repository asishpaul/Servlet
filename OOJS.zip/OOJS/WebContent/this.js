function employee(empId,firstNmae,lastNmae,salary){
	this.empId=empId
	this.firstNmae=firstNmae
	this.lastNmae=lastNmae
	this.salary=salary
	
	this.getName=function(){
		return this.firstNmae+' '+this.lastNmae
	}
	
}

var emp=employee(1004,'tom','jerry',2300)
console.log('Emp id:'+emp.empId)