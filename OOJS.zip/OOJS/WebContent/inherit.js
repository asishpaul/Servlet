function Employee(name){
	this.name=name
}

Employee.prototype.getName=function(){
	return this.name;
}


function Dep(name,mgr)
{this.name=name
	this.mgr=mgr
	
}

Dep.prototype.getDepMgr=function(){
	return this.mgr
}

var emp=new Employee('jack')
console.log(emp)
console.log(name)

var dep1=new Dep('sales','tom')
console.log(dep1)
console.log(dep1.getDepMgr())

/*dep1.__proto__=emp
//var dep2=new Dep('sales','tom')
console.log(dep1)
console.log(dep1._proto_.getName())
console.log(dep1.getDepMgr())
//console.log(dep1.__proto__.getDepMgr())
*/
Dep.prototype=new Employee('jackson')
var dep1=new Dep('sales','tomy')
console.log(dep1.getName())






