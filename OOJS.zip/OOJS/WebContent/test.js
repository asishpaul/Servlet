var emp=new Object({
	empId:1001,
	empName:'Tom',
	salary:3400,
	greet: function(){
		alert('Hi '+this.empId+'.');
	}
	
	
})