var emp=[{
		
		"empid" : 1001,
		"empname" : "tom",
		"department" : ["sales","purchase"],
		"isPermanent" : true,
		"address" : {"strNmae" : "3/1,north avenue",
			
		"city" : "chennai",
		"pincode" : "356767"}


},
{
"empid" : 1002,
"empname" : "jack",
"department" : ["sales","finance"],
"isPermanent" : false,
"address" : {"strNmae" : "4/1,south avenue",
	
"city" : "bangalore",
"pincode" : "64884"}

}
]
console.log(emp)